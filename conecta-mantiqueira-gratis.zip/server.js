const path = require("path");
const crypto = require("crypto");
const express = require("express");
const pg = require("pg");

const { Pool } = pg;
const app = express();
const PORT = Number(process.env.PORT || 3000);

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL não definida. Configure a variável no ambiente do servidor.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : false,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const SESSION_DAYS = 30;

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      age INTEGER,
      city TEXT,
      bio TEXT,
      avatar_url TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at TIMESTAMPTZ NOT NULL
    );

    CREATE TABLE IF NOT EXISTS posts (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT NOT NULL,
      city TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS messages (
      id SERIAL PRIMARY KEY,
      sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      receiver_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      CHECK (sender_id <> receiver_id)
    );

    CREATE INDEX IF NOT EXISTS idx_users_city ON users(city);
    CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_posts_city ON posts(city);
    CREATE INDEX IF NOT EXISTS idx_messages_pair
      ON messages(sender_id, receiver_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_sessions_user
      ON sessions(user_id);
  `);
}

function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function cleanText(value, max = 5000) {
  return String(value || "").trim().slice(0, max);
}

function hashPassword(password) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16);
    crypto.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) return reject(err);
      resolve(`${salt.toString("hex")}:${derivedKey.toString("hex")}`);
    });
  });
}

function verifyPassword(password, stored) {
  return new Promise((resolve, reject) => {
    const [saltHex, keyHex] = String(stored || "").split(":");
    if (!saltHex || !keyHex) return resolve(false);
    const salt = Buffer.from(saltHex, "hex");
    const expected = Buffer.from(keyHex, "hex");
    crypto.scrypt(password, salt, expected.length, (err, derived) => {
      if (err) return reject(err);
      resolve(crypto.timingSafeEqual(expected, derived));
    });
  });
}

function publicUser(row) {
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    age: row.age,
    city: row.city,
    bio: row.bio,
    avatarUrl: row.avatar_url,
    createdAt: row.created_at,
  };
}

async function createSession(userId) {
  const token = crypto.randomBytes(32).toString("hex");
  await pool.query(
    `INSERT INTO sessions (token, user_id, expires_at)
     VALUES ($1, $2, NOW() + INTERVAL '30 days')`,
    [token, userId]
  );
  return token;
}

async function auth(req, res, next) {
  try {
    const token = req.headers.authorization?.replace(/^Bearer\s+/i, "").trim();
    if (!token) return res.status(401).json({ error: "Não autenticado." });

    const result = await pool.query(
      `SELECT u.*
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token = $1 AND s.expires_at > NOW()`,
      [token]
    );

    if (!result.rows[0]) return res.status(401).json({ error: "Sessão inválida ou expirada." });
    req.user = result.rows[0];
    req.token = token;
    next();
  } catch (err) {
    next(err);
  }
}

app.get("/api/health", async (_req, res, next) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, service: "conecta-mantiqueira" });
  } catch (err) {
    next(err);
  }
});

app.post("/api/register", async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = String(req.body.password || "");
    const name = cleanText(req.body.name, 80);
    const age = Number.isInteger(Number(req.body.age)) ? Number(req.body.age) : null;
    const city = cleanText(req.body.city, 80);
    const bio = cleanText(req.body.bio, 500);

    if (!email || !password || !name) {
      return res.status(400).json({ error: "Nome, e-mail e senha são obrigatórios." });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: "A senha precisa ter pelo menos 6 caracteres." });
    }

    const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email]);
    if (existing.rows[0]) {
      return res.status(409).json({ error: "Este e-mail já está cadastrado." });
    }

    const passwordHash = await hashPassword(password);
    const result = await pool.query(
      `INSERT INTO users (email, password_hash, name, age, city, bio)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [email, passwordHash, name, age, city, bio]
    );

    const token = await createSession(result.rows[0].id);
    res.status(201).json({ token, user: publicUser(result.rows[0]) });
  } catch (err) {
    next(err);
  }
});

app.post("/api/login", async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = String(req.body.password || "");

    const result = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
    const user = result.rows[0];

    if (!user || !(await verifyPassword(password, user.password_hash))) {
      return res.status(401).json({ error: "E-mail ou senha inválidos." });
    }

    const token = await createSession(user.id);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    next(err);
  }
});

app.post("/api/logout", auth, async (req, res, next) => {
  try {
    await pool.query("DELETE FROM sessions WHERE token = $1", [req.token]);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

app.get("/api/me", auth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.put("/api/profile", auth, async (req, res, next) => {
  try {
    const name = cleanText(req.body.name, 80);
    const age = Number.isInteger(Number(req.body.age)) ? Number(req.body.age) : null;
    const city = cleanText(req.body.city, 80);
    const bio = cleanText(req.body.bio, 500);
    const avatarUrl = cleanText(req.body.avatarUrl, 1000);

    if (!name) return res.status(400).json({ error: "Nome é obrigatório." });

    const result = await pool.query(
      `UPDATE users
       SET name = $1, age = $2, city = $3, bio = $4, avatar_url = $5
       WHERE id = $6
       RETURNING *`,
      [name, age, city, bio, avatarUrl || null, req.user.id]
    );

    res.json({ user: publicUser(result.rows[0]) });
  } catch (err) {
    next(err);
  }
});

app.get("/api/users", auth, async (req, res, next) => {
  try {
    const q = cleanText(req.query.q, 100);
    const city = cleanText(req.query.city, 80);

    const result = await pool.query(
      `SELECT *
       FROM users
       WHERE id <> $1
         AND ($2 = '' OR name ILIKE '%' || $2 || '%' OR COALESCE(bio, '') ILIKE '%' || $2 || '%')
         AND ($3 = '' OR city ILIKE '%' || $3 || '%')
       ORDER BY created_at DESC
       LIMIT 100`,
      [req.user.id, q, city]
    );

    res.json({ users: result.rows.map(publicUser) });
  } catch (err) {
    next(err);
  }
});

app.get("/api/posts", auth, async (req, res, next) => {
  try {
    const city = cleanText(req.query.city, 80);
    const result = await pool.query(
      `SELECT p.*, u.name, u.avatar_url
       FROM posts p
       JOIN users u ON u.id = p.user_id
       WHERE ($1 = '' OR p.city ILIKE '%' || $1 || '%')
       ORDER BY p.created_at DESC
       LIMIT 100`,
      [city]
    );

    res.json({
      posts: result.rows.map((p) => ({
        id: p.id,
        body: p.body,
        city: p.city,
        createdAt: p.created_at,
        user: {
          id: p.user_id,
          name: p.name,
          avatarUrl: p.avatar_url,
        },
      })),
    });
  } catch (err) {
    next(err);
  }
});

app.post("/api/posts", auth, async (req, res, next) => {
  try {
    const body = cleanText(req.body.body, 2000);
    const city = cleanText(req.body.city || req.user.city, 80);

    if (!body) return res.status(400).json({ error: "A publicação não pode estar vazia." });

    const result = await pool.query(
      `INSERT INTO posts (user_id, body, city)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [req.user.id, body, city]
    );

    res.status(201).json({
      post: {
        ...result.rows[0],
        user: publicUser(req.user),
      },
    });
  } catch (err) {
    next(err);
  }
});

app.get("/api/conversations", auth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `WITH ranked AS (
        SELECT
          m.*,
          CASE WHEN m.sender_id = $1 THEN m.receiver_id ELSE m.sender_id END AS other_id,
          ROW_NUMBER() OVER (
            PARTITION BY CASE WHEN m.sender_id = $1 THEN m.receiver_id ELSE m.sender_id END
            ORDER BY m.created_at DESC
          ) AS rn
        FROM messages m
        WHERE m.sender_id = $1 OR m.receiver_id = $1
      )
      SELECT r.id, r.body, r.created_at, u.id AS other_user_id, u.name AS other_user_name, u.avatar_url
      FROM ranked r
      JOIN users u ON u.id = r.other_id
      WHERE r.rn = 1
      ORDER BY r.created_at DESC`,
      [req.user.id]
    );

    res.json({
      conversations: result.rows.map((r) => ({
        id: r.id,
        body: r.body,
        createdAt: r.created_at,
        user: {
          id: r.other_user_id,
          name: r.other_user_name,
          avatarUrl: r.avatar_url,
        },
      })),
    });
  } catch (err) {
    next(err);
  }
});

app.get("/api/messages/:userId", auth, async (req, res, next) => {
  try {
    const otherId = Number(req.params.userId);
    if (!Number.isInteger(otherId) || otherId <= 0) {
      return res.status(400).json({ error: "Usuário inválido." });
    }

    const result = await pool.query(
      `SELECT *
       FROM messages
       WHERE (sender_id = $1 AND receiver_id = $2)
          OR (sender_id = $2 AND receiver_id = $1)
       ORDER BY created_at ASC
       LIMIT 500`,
      [req.user.id, otherId]
    );

    res.json({ messages: result.rows });
  } catch (err) {
    next(err);
  }
});

app.post("/api/messages/:userId", auth, async (req, res, next) => {
  try {
    const otherId = Number(req.params.userId);
    const body = cleanText(req.body.body, 3000);

    if (!Number.isInteger(otherId) || otherId <= 0 || otherId === req.user.id) {
      return res.status(400).json({ error: "Destinatário inválido." });
    }
    if (!body) return res.status(400).json({ error: "A mensagem não pode estar vazia." });

    const target = await pool.query("SELECT id FROM users WHERE id = $1", [otherId]);
    if (!target.rows[0]) return res.status(404).json({ error: "Usuário não encontrado." });

    const result = await pool.query(
      `INSERT INTO messages (sender_id, receiver_id, body)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [req.user.id, otherId, body]
    );

    res.status(201).json({ message: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Erro interno do servidor." });
});

app.get("/{*splat}", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Conecta Mantiqueira rodando na porta ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Falha ao inicializar o banco:", err);
    process.exit(1);
  });

process.on("SIGTERM", async () => {
  await pool.end();
  process.exit(0);
});
