# Conecta Mantiqueira Web 1.0 — modo gratuito

Esta versão está preparada para colocar o site no ar sem contratar servidor ou banco pago.

## Estrutura gratuita

- **Render Free**: hospeda o servidor Web Node/Express.
- **Supabase Free**: hospeda o PostgreSQL.
- O projeto recebe a conexão do banco pela variável `DATABASE_URL`.

### Limitações importantes

O Render Free desliga o serviço após 15 minutos sem tráfego e pode levar cerca de 1 minuto para acordar na próxima visita. A hospedagem gratuita é indicada para testes e projetos iniciais. O Supabase Free possui limites de uso e pode pausar projetos gratuitos após período de inatividade.

## Como publicar

### 1. Criar o banco gratuito no Supabase

Crie um projeto no Supabase usando o plano Free.

Depois, copie a string de conexão PostgreSQL do projeto. Para este servidor Node/Express, prefira a conexão por pooler quando o painel oferecer essa opção.

### 2. Colocar o código no GitHub

Crie um repositório e envie todos os arquivos desta pasta.

### 3. Publicar no Render

No Render:
- New
- Blueprint
- selecione o repositório
- o Render usará o `render.yaml`
- mantenha o serviço como Free

Quando pedir a variável `DATABASE_URL`, cole a string PostgreSQL do Supabase.

### 4. Testar

Depois do deploy, abra:

`https://SEU-ENDERECO.onrender.com/api/health`

O resultado esperado é algo como:

`{"ok":true,"service":"conecta-mantiqueira"}`

Depois abra o endereço principal do site.

## Próximos passos do projeto

1. Fotos de perfil e publicações
2. Recuperação de senha
3. Denúncia e bloqueio
4. Empresas e serviços
5. Notificações
6. Painel administrativo
7. Termos de uso e privacidade
8. Domínio próprio
9. Aplicativo Android/iPhone

Quando o projeto crescer, podemos migrar o banco e o servidor para planos pagos sem reescrever o aplicativo.
